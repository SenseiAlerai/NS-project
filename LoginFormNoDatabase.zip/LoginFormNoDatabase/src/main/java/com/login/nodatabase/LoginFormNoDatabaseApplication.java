package com.login.nodatabase;

import com.login.Entity.Clientlist;
import com.login.Entity.ClientlistDAO;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

@SpringBootApplication
@ComponentScan("com.login")
@EnableJpaAuditing
public class LoginFormNoDatabaseApplication {


	public static void main(String[] args) {
		SpringApplication.run(LoginFormNoDatabaseApplication.class, args);
//		try {
//			getconnection();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		ClientlistDAO ABC = new ClientlistDAO();
//		ABC.getAllclients();

	}

//	public static Connection getconnection() throws Exception  {
//		try {
//			String driver = "com.mysql.cj.jdbc.Driver";
//			String url = "jdbc:mysql://localhost:3306/nbs";
//			String username = "root";
//			String password = "Whokilledme1@";
//			Class.forName(driver);
//
//			Connection conn = DriverManager.getConnection(url, username, password);
//			System.out.println("connected");
//;
//			return conn;
//		} catch (Exception e){System.out.println(e);}
//		return  null;
//
//	}






}





