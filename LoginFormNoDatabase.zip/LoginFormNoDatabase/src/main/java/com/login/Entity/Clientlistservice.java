package com.login.Entity;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public class Clientlistservice implements Clienttable {

    @Autowired
    private ClientlistDAO clientlistdao;
    private  Clientlist clientlist;

    @Override
    public List<Clientlist> getAllclients() {
        return clientlistdao.getAllclients();
    }

    @Override
    public <S extends Clientlist> S save(S entity) {
        return null;
    }

    @Override
    public <S extends Clientlist> Iterable<S> saveAll(Iterable<S> entities) {
        return null;
    }

    @Override
    public Optional<Clientlist> findById(String s) {
        return Optional.empty();
    }

    @Override
    public boolean existsById(String s) {
        return false;
    }

    @Override
    public Iterable<Clientlist> findAll() {
        return null;
    }

    @Override
    public Iterable<Clientlist> findAllById(Iterable<String> strings) {
        return null;
    }

    @Override
    public long count() {
        return 0;
    }

    @Override
    public void deleteById(String s) {

    }

    @Override
    public void delete(Clientlist entity) {

    }

    @Override
    public void deleteAll(Iterable<? extends Clientlist> entities) {

    }

    @Override
    public void deleteAll() {

    }
}
