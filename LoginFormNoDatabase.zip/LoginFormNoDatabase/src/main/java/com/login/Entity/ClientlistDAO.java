package com.login.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ClientlistDAO {
    JdbcTemplate template;

    @Autowired
    public void setDataSource (DataSource dataSource){
        template= new JdbcTemplate(dataSource);

    }

    private static Connection initialize() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/nbs","root","Whokilledme1@");
    }

    public void save (Clientlist p){
        String sql ="insert into clientlist(name,email,position,address) values ( '"+p.getName()+"' ,'"+p.getEmail()+"', '"+p.getPosition()+"','"+p.getAddress()+"')";
        template.update(sql);
    }
    
    // method to show all the client existing in the database
    public  List<Clientlist> getAllclients(){
        return template.query("select * from nbs.clientdata", new ResultSetExtractor<List<Clientlist>>() {
            @Override
            public List<Clientlist> extractData(ResultSet rs) throws SQLException, DataAccessException {

                List<Clientlist> list=  new ArrayList<Clientlist>();
                while (rs.next()) {
                    Clientlist e= new Clientlist();
                    e.setId(rs.getInt(1));
                    e.setName(rs.getString(2));
                    e.setPosition(rs.getString(3));
                    e.setEmail(rs.getString(4));
                    e.setAddress(rs.getString(5));

                    list.add(e);
                }

                System.out.println(list.size());


                for (Clientlist client: list){
                    System.out.println(client.toString());
                }

                return list;
            }
        });
    }
    // method to show all the client existing in the database
//    public List<Clientlist> getclientsByPage(int pageid, int total){
//        String sql = "select * from clientdata limit"+ (pageid-1)+","+total;
//        return template.query(sql, new ResultSetExtractor<List<Clientlist>>() {
//            @Override
//            public List<Clientlist> extractData(ResultSet rs) throws SQLException, DataAccessException {
//
//                List<Clientlist> list=  new ArrayList<Clientlist>();
//                while (rs.next()) {
//                    Clientlist e= new Clientlist();
//                    e.setId(rs.getInt(1));
//                    e.setName(rs.getString(2));
//                    e.setPosition(rs.getString(3));
//                    e.setEmail(rs.getString(4));
//                    e.setAddress(rs.getString(5));
//
//                    list.add(e);
//                }
//                return list;
//            }
//        });
//    }

    public void update (Clientlist p){
        String sql = "update Clientlist set name='"+p.getName()+"', email='"+p.getEmail()+"', position='"+p.getPosition()+"', Address='"+p.getAddress()+"', where id="+p.getId()+"";
        template.update(sql);
    }

//    public void delete (int id){
//        String sql = "delete from clientdata where Id= "+id+"";
//        template.update(sql);
//    }
//    public void delete(){
//        String sql ="delete from clientdata where Id>0";
//        template.update(sql);
//    }
}
