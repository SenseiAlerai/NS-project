package com.login.Entity;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;


@Entity

public class Clientlist implements Serializable  {
    private static final long serialVersionUID = 1L;
//    implements Serializable



//    id int(10),
    //    name char(20),
    //    position varchar(20),
//    email varchar(30),
//    address varchar(20));

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Id;
    @NotEmpty
    private String Name;

    @NotEmpty
    private String Position;

    @Email
    private String Email;
    @NotEmpty
    private String Address;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPosition() {
        return Position;
    }

    public void setPosition(String position) {
        Position = position;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    @Override
    public String toString() {
        return "Clientlist [Id=" + Id + ", Name=" + Name + ", Position=" + Position + ", Email="
                + Email + ", Address=" + Address + "]";
    }

}
