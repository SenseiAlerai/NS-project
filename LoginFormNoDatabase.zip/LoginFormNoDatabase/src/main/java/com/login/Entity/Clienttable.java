package com.login.Entity;
import com.login.Entity.Clientlist;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface Clienttable extends CrudRepository<Clientlist, String> {
    List<Clientlist> getAllclients();

}
