package com.login.controller;

import com.login.Entity.Clientlist;
import com.login.Entity.ClientlistDAO;
import com.login.Entity.Clientlistservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.login.service.LoginService;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@SessionAttributes("name")
public class LoginController  {

    @Autowired
    LoginService service;


    @RequestMapping(value="/login", method = RequestMethod.GET)
    public String showLoginPage(ModelMap model){
        return "login";
    }

    @RequestMapping(value="/login", method = RequestMethod.POST)
    public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){

        boolean isValidAdmin = service.validateUser(name, password);
        boolean isValidClient = service.clientuser(name, password);

        if (isValidAdmin) {
            model.put("errorMessage", "Invalid Credentials");
            return "index";
        } else if (isValidClient) {
          return "clientdashboard";
        }

        if(!isValidClient || !isValidAdmin) {
          model.put("error message", "Invalid Credentials");
          return "login";
        }
        
        model.put("error message", "Invalid Credentials");

        return "login";
    }
    
//    @RequestMapping(value="/activity", method = RequestMethod.POST)
    @GetMapping(value="/activity")
    public String showActivityPage (ModelMap model) {
		return "activity";
    	
    }
    
//    @RequestMapping(value="/registeruser", method = RequestMethod.POST)
    @GetMapping(value="/registeruser")
    public String showRegisterPage (ModelMap model) {
		return "registeruser";
    	
    }
    
//    @RequestMapping(value="/clienttable", method = RequestMethod.POST)
    @GetMapping(value="/brainstorm")
    public String showBrainstormPage (ModelMap model) {
		return "brainstorm";
    	
    }
    
    @GetMapping(value="/profile")
    public String showProfilePage (ModelMap model) {
		return "profile";
    	
    }

    
    @GetMapping(value="/clienttable")
    public String showTablePage (ModelMap model) {
        Clientlist Clientlist= new Clientlist ();
        model.addAttribute("Clientlist", Clientlist);
		return "tables";
    	
    }


    
    @GetMapping(value="/index")
    public String showIndexPage (ModelMap model) {
		return "index";
    	
    }
    
    @GetMapping(value="/dashboard")
    public String showDashPage (ModelMap model) {
		return "clientdashboard";
    	
    }
    
    @GetMapping(value="/cprofile")
    public String showCprofilePage (ModelMap model) {
		return "clientprofile";
    	
    }
    
    
    @GetMapping(value="/cactivity")
    public String showCactivityPage (ModelMap model) {
		return "clientactivity";
    	
    }
    
    @GetMapping (value="/cbrainstorm")
    public String showClientbrainstormPage (ModelMap model) {
    	return "clientbrainstorm";
    }

    
    
    
    
    
    
    
   
 
}