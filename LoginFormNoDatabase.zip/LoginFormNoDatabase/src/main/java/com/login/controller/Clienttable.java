package com.login.controller;

import com.login.Entity.Clientlist;
import com.login.Entity.Clientlistservice;
import com.login.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@SessionAttributes("name")
public class Clienttable {

    @Autowired
    LoginService service;
    Clientlistservice clientlistservice;

    @RequestMapping("/clienttable")
    public ModelAndView viewclients(){
        List<Clientlist> clientlist= clientlistservice.getAllclients();
        return new ModelAndView("viewclients","list",clientlist);
    }
}
