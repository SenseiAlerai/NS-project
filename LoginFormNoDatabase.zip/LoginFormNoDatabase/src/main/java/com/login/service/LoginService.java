package com.login.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
public class LoginService {

    public boolean validateUser(String userid, String password) {
        
        return userid.equalsIgnoreCase("admin")
                && password.equalsIgnoreCase("12345");
    }
    
    public boolean clientuser(String userid, String password) {
        
        return userid.equalsIgnoreCase("client")
                && password.equalsIgnoreCase("12345");
    }

}
