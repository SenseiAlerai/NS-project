package com.login.User;

import javax.persistence.Entity;

@Entity
public class User {


}
